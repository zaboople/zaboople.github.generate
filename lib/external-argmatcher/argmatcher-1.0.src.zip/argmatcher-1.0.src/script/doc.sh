cd $(dirname $0)/..
ant javadoc


