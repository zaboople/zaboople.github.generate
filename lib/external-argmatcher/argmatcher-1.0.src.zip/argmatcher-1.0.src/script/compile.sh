cd $(dirname $0)/..
ant compile
